import React from 'react'
import { Link } from 'react-router-dom';

const Home = () => {
    const handleBackButtton = () => {
        window.history.back();
    }
    return (
        <div className=' br5 pa5 ma5'>
            <div className='tc  bg-lightest-blue dib br3 pa4 ma2 bw2 shadow-5'>
                <strong>READ THE INSTRUCTIONS CAREFULLY:</strong>
                <h4 className=' fw4 tracked f5 ph2 mh2' >If you wish to donate blood, click on DONATE button.</h4>
                <Link to='/Donate'>
                    <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib'>DONATE</button>
                </Link>
                <h4 className=' fw4 tracked f5 ph2 mh2'>If you want to request for blood or platelets, click on REQUEST button.</h4>
                <Link to='/Request'>
                    <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib'>REQUEST</button>
                </Link>
                <div>
                    <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib' onClick={handleBackButtton}>BACK</button>
                </div>
            </div>
        </div>
    )
}
export default Home;