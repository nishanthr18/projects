import React from 'react'

const Donate = () => {
    const handleBackButtton = () => {
        window.history.back();
    }
    return (
        <div className=' br5 pa5 ma5'>
            <div className='tc  bg-lightest-blue dib br3 pa3 ma2 bw2 shadow-5'>
                <h4>DONATE here</h4>
                <div>
                    <p className=' fw4 tracked f5 ph2 mh2'>If you wish to donate BLOOD click on "BLOOD" button</p>
                    <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib'>BLOOD</button>
                </div>
                <div>
                    <p className=' fw4 tracked f5 ph2 mh2'>If you wish to donate PLATELETS click on "PLATELETS" button</p>
                    <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib'>PLATELETS</button>
                </div>
                <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib' onClick={handleBackButtton}>Back</button>
            </div>
        </div>
    )
}
export default Donate;