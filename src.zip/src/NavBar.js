import React from 'react'

const NavBar = () => {
    return (
        <nav className=' grow bw2 shadow-5' >
            <ul>
                <h1>QUICK-BLOOD</h1>
                <p>spread care, save lives</p>
            </ul>
        </nav>

    )
}
export default NavBar;