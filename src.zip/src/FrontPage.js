import React from 'react';
import SignIn from './SignIn';
import { Link } from 'react-router-dom';



const FrontPage = () => {
    return (
        <div className='frontpage'>
            <div className='tc relative bg-lightest-blue dib br3 pa4 ma5 bw2 shadow-5'>
                <SignIn />
                <div className='ttu fw4 tracked f11 ph0 mh0'>
                    <p>if you have not registered yet, please register here</p>
                    <Link to='./Register'>
                        <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib'> Register</button>
                    </Link>
                </div>
            </div>
        </div>
    )
}

export default FrontPage;