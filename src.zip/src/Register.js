import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { Link } from 'react-router-dom';

class Register extends Component {
    constructor() {
        super()
        this.state = {
            fullname: '',
            email: '',
            age: '',
            contact: '',
            blood_group: '',
            password: '',
            confirm_password: '',
            isCheckboxValid: false
        }

    }
    namehandleChange = (e) => {
        this.setState({
            fullname: e.target.value
        })
    }
    emailhandleChange = (e) => {
        this.setState({
            email: e.target.value
        })
    }
    agehandleChange = (e) => {
        this.setState({
            age: e.target.value
        })
    }
    contacthandleChange = (e) => {
        this.setState({
            contact: e.target.value
        })
    }
    bloodgrouphandleChange = (e) => {
        this.setState({
            blood_group: e.target.value
        })
    }
    passwordhandleChange = (e) => {
        this.setState({
            password: e.target.value
        })
    }
    confirmpasswordhandleChange = (e) => {
        this.setState({
            confirm_password: e.target.value
        })
    }
    handleCheckBoxTC = () => {
        this.setState({
            isCheckboxValid: !this.state.isCheckboxValid
        })
    }

    handleClick = () => {
        if (this.state.fullname === '' && this.state.email === '' && this.state.age === '' && this.state.contact === '' && this.state.blood_group === '' && this.state.password === '' && this.state.confirm_password === '') {
            return alert('you have to fill all the given credentials!')
        } else if (this.state.fullname.length < 3) {
            return alert('name is too short!')
        } else if (this.state.email.indexOf('@') === -1) {
            return alert('provide valid email')
        } else if (this.state.age.length < 1) {
            return alert('provide valid age')
        } else if (this.state.contact.length !== 10) {
            return alert('provide valid contact number')
        } else if (this.state.password !== this.state.confirm_password) {
            return alert('password did not match')
        }
        else {
            alert('You have successfully Registered. You can go back and Signin now!')
        }
        this.setState({
            fullname: '',
            email: '',
            age: '',
            contact: '',
            blood_group: '',
            password: '',
            confirm_password: '',
            isCheckboxValid: false
        })
    }

    goBack = () => {
        window.history.back();
    }
    render() {
        return (
            <div className='form-inputs'>
                <div className='tc bg-lightest-blue dib br2 pa2 w-50 ma2 bw2 shadow-5'>
                    <h3 className='ttu fw6 tracked f4 ph0 mh0'>REGISTER here</h3>
                    <div className='tc w-5 bg-light-green dib br3 pa3  ma2 bw2 shadow-5'>
                        <div>
                            <label className='db fw6 lh-copy f6'>FullName</label>
                            <input className='ma1.5' type='text' value={this.state.fullname} onChange={this.namehandleChange} required />

                            <div>
                                <label className='db fw6 lh-copy f6'>Email</label>
                                <input className='ma2' type='email' value={this.state.email} onChange={this.emailhandleChange} required />

                                <div>
                                    <label className='db fw6 lh-copy f6'>Age</label>
                                    <input className='ma2' type='number' value={this.state.age} onChange={this.agehandleChange} required />

                                    <div>
                                        <label className='db fw6 lh-copy f6'>Contact no</label>
                                        <input className='ma2' type='text' value={this.state.contact} onChange={this.contacthandleChange} required />

                                        <div>
                                            <label className='db fw6 lh-copy f6'>Blood Group</label>
                                            <input className='ma2' type='text' value={this.state.blood_group} onChange={this.bloodgrouphandleChange} required />

                                            <div>
                                                <label className='db fw6 lh-copy f6'>Password</label>
                                                <input className='ma2' type='password' value={this.state.password} onChange={this.passwordhandleChange} required />

                                                <div>
                                                    <label className='db fw6 lh-copy f6'>Confirm Password</label>
                                                    <input className='ma2' type='password' value={this.state.confirm_password} onChange={this.confirmpasswordhandleChange} required />
                                                    <div>
                                                        <Link to='./TandC'>
                                                            <a href='terms and conditions'>terms and conditions</a>
                                                        </Link>
                                                        <div>
                                                            <label class='1h-copy f6 pointer '><input className='ma2' onClick={this.handleCheckBoxTC} type='checkbox' />By clicking Register,you agree to our terms and conditions</label>
                                                            <div >
                                                                <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib' disabled={!this.state.isCheckboxValid} onClick={this.handleClick} >Register</button>
                                                                <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib' onClick={this.goBack}>Back</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )

    }
}



export default withRouter(Register);

