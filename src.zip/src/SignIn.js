import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class SignIn extends Component {
    constructor() {
        super()
        this.state = {
            userName: '',
            password: ''
        }
    }

    handleUsername = (e) => {
        this.setState({
            userName: e.target.value
        })
    }

    handlePassword = (e) => {
        this.setState({
            password: e.target.value
        })
    }

    onSigninClick = () => {
        if (this.state.userName.length >= 5 && this.state.password.length >= 5) {
            this.props.history.push('/Home')
        } else {
            alert(`you've to enter all the fields!`)
            this.setState({
                userName: '',
                password: ''
            })
        }
    }
    render() {
        return (
            <div className='sign-in'>
                <h3 className='ttu fw6 tracked f4 ph0 mh0'>SIGN-IN here</h3>
                <div>
                    <div className='tc bg-light-green dib br3 pa3 grow ma2 bw2 shadow-5'>
                        <label className='db fw6 lh-copy f6'>Username/Email</label>
                        <input type='text' value={this.state.userName} onChange={this.handleUsername} required />
                        <div className='pa2 input-reset  mb2 db w-100'>
                            <label className='db fw6 lh-copy f6'>Password</label>
                            <input type='password' value={this.state.password} onChange={this.handlePassword} required />
                            <div>
                                <label class='1h-copy f6 pointer '><input className='ma2' type='checkbox' />Remember me</label>
                                <div>
                                    <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib' onClick={this.onSigninClick}>sign in</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default withRouter(SignIn);