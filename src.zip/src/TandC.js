import React from 'react'

const TandC = () => {
    const goBack = () => {
        window.history.back();
    }
    return (
        <div className='tc bg-lightest-blue dib br3 pa2 w-50 ma2 bw2  shadow-5'>
            <h1>PLEASE READ ALL THE TERMS AND CONDITIONS CAREFULLY</h1>
            <p>1. Before REGSITERING make sure you read all the terms and conditions carefully.</p>
            <p>2. Any fraudent calls and spam text is not under responsibility </p>
            <p>3. Its a free will website, if u unable to catch donor, its not our responsibility</p>
            <p>4. Your Details will be safe and secured</p>
            <div>
                <button className='b ma2 ph3 pv1 input-reset ba b--black bg-transparent grow pointer f6 dib' onClick={goBack}>Back</button>
            </div>
        </div>
    )
}

export default TandC;