import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import FrontPage from './FrontPage';
import Home from './Home';
import NavBar from './NavBar';
import Register from './Register';
import SignIn from './SignIn';
import Donate from './Donate';
import Request from './Request';
import TandC from './TandC';
import './App.css';

const App = () => {
    return (
        <Router>
            <div className='App'>
                <NavBar />
                <Switch>
                    <Route path='/' exact component={FrontPage} />
                    <Route path='/SignIn' exact component={SignIn} />
                    <Route path='/Home' exact component={Home} />
                    <Route path='/Register' exact component={Register} />
                    <Route path='/Donate' exact component={Donate} />
                    <Route path='/Request' exact component={Request} />
                    <Route path='/TandC' exact component={TandC} />
                </Switch>
            </div>
        </Router>
    )
}
export default App;